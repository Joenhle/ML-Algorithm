import pandas as pd
import math
import csv
import random
import numpy as np
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression

base_elo = 1600
team_elos = {}
team_stats = {}
X = []
y = []

# 计算每个球队的elo值
def calc_elo(win_team, lose_team):
    winner_rank = get_elo(win_team)
    loser_rank = get_elo(lose_team)

    rank_diff = winner_rank - loser_rank
    exp = (rank_diff * -1) / 400
    odds = 1 / (1 + math.pow(10, exp))
    # 根据rank级别修改K值
    if winner_rank < 2100:
        k = 32
    elif winner_rank >= 2100 and winner_rank < 2400:
        k = 24
    else:
        k = 16

    # 更新 rank 数值
    new_winner_rank = round(winner_rank + (k * (1 - odds)))
    new_loser_rank = round(loser_rank + (k * (0 - odds)))
    return new_winner_rank, new_loser_rank

def get_elo(team):
    try:
        return team_elos[team]
    except:
        # 当最初没有elo时，给每个队伍最初赋base_elo
        team_elos[team] = base_elo
        return team_elos[team]


def get_team_data():
    f = open('data1')
    team_data = {}
    for row in f.readlines()[1:]:
        split = row.split(',')
        arr = []
        for i in range(4,len(split)):
            arr.append(float(split[i].replace('\n','')))
        team_data[split[1].replace('*', '')] = arr
    return team_data

def get_game_data():
    f = open('data2')
    data = []
    for row in f.readlines()[1:]:
        split = row.split(',')
        if(int(split[3]) > int(split[5])):
            data.append([split[2],split[4],'V'])
        else:
            data.append([split[4],split[2],'H'])
    return data

def build_dataSet(game_data):

    team_data = get_team_data()
    for index, row in enumerate(game_data):
        Wteam = row[0]
        Lteam = row[1]

        #获取最初的elo或是每个队伍最初的elo值
        team1_elo = get_elo(Wteam)
        team2_elo = get_elo(Lteam)

        # 给主场比赛的队伍加上100的elo值
        if row[2] == 'H':
            team1_elo += 100
        else:
            team2_elo += 100

        # 把elo当为评价每个队伍的第一个特征值
        team1_features = [team1_elo]
        team2_features = [team2_elo]

        #补充每个队伍的特征
        team1_features.extend(team_data[Wteam])
        team2_features.extend(team_data[Lteam])

        # 将两支队伍的特征值随机的分配在每场比赛数据的左右两侧
        # 并将对应的0/1赋给y值
        if random.random() > 0.5:
            X.append(team1_features + team2_features)
            y.append(0)
        else:
            X.append(team2_features + team1_features)
            y.append(1)

        # 根据这场比赛的数据更新队伍的elo值
        new_winner_rank, new_loser_rank = calc_elo(Wteam, Lteam)
        team_elos[Wteam] = new_winner_rank
        team_elos[Lteam] = new_loser_rank

    return np.nan_to_num(X), np.array(y)

def predict_winner(team_1, team_2, model):
    features = []
    team_data = get_team_data()

    #team1 客场队伍
    features.append(get_elo(team_1))
    features.extend(team_data[team_1])

    #team2 主场队伍
    features.append(get_elo(team_2) + 100)
    features.extend(team_data[team_2])

    features = np.nan_to_num(features)
    return model.predict_proba([features])

if __name__ == '__main__':

    game_data = get_game_data()
    X, y = build_dataSet(game_data)

    # 训练网络模型
    model = LogisticRegression(max_iter=5000)
    model.fit(X,y)

    # 利用10折交叉验证计算训练正确率
    print(cross_val_score(model, X, y, cv=10, scoring='accuracy', n_jobs=-1).mean())

    #对16年的比赛结果进行预估
    result = []
    f = open('data3')
    for row in f.readlines()[1:]:
        split = row.split(',')
        Vteam = split[2]
        Hteam = split[3]
        if(Vteam == 'Cleveland Cavalier'):
            Vteam = 'Cleveland Cavaliers'
        pred = predict_winner(Vteam, Hteam, model)
        prob = pred[0][0]
        if prob > 0.5:
            winner = Vteam
            loser = Hteam
            result.append([winner,loser,prob])
        else:
            winner = Hteam
            loser = Vteam
            result.append([winner,loser,1-prob])

    with open('2016_NBA_Result.csv','w') as f:
        writer = csv.writer(f)
        writer.writerow(['winner','losser','probability'])
        writer.writerows(result)








